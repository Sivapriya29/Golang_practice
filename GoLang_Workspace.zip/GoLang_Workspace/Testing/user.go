package test

import "fmt"

func GetMax(a []int) int {
	var max int

	for _, v := range a {
		if max < v {
			max = v
		}
	}
	return max
}

type User struct {
	ID   string
	Name string
}

type UserDao interface {
	Persist(u *User) error
	Update(u *User) error
	Get(id string) (*User, error)
	Delete(id string) error
}

type UserPostg struct {
}

func InsertUser(u UserDao, user *User) error {
	err := u.Persist(user)
	if err != nil {
		fmt.Println("Unable to persist user. Err:", err)
		return err
	}
	return nil
}
