package test

import (
	"testing"

	"github.com/golang/mock/gomock"
)

// func TestGetMax(t *testing.T) {
// 	m := GetMax([]int{1, 2, 3, 4})

//		if m != 4 {
//			t.Error("The max value should be 4")
//		}
//	}
func TestUserPersist(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()
	m := NewMockUserDao(ctrl)
	user := &User{
		ID: "10",
		//Name: "test",
	}
	m.EXPECT().Persist(user).Return(nil)
	err := InsertUser(m, user)
	if err != nil {
		t.Error("Failed to insert user, Err:", err)
	}
}

// func TestGetMaxWithVariable(t *testing.T) {
// 	a := []int{1, 2, 3, 4, 9, 11, 8}
// 	m := GetMax(a)
// 	if m != 10 {
// 		t.Error("The max value should be 10")
// 	}
// }
