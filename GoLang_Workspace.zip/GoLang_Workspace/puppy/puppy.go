package puppy

func Bark() string {
	return "Woof!!"
}

func Barks() string {
	return "Woof! Woof! Woof!"
}
