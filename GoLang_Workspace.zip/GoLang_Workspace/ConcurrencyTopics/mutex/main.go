package main

import (
	"fmt"
	"sync"
	"time"
)

var counter int      // Shared variable to be protected by mutex
var mutex sync.Mutex // Mutex to protect counter

func incrementCounter() {
	mutex.Lock()         // Lock the mutex before accessing the shared variable
	defer mutex.Unlock() // Ensure to unlock the mutex when the function exits

	// Simulate some work
	time.Sleep(time.Millisecond * 100)

	counter++ // Increment the shared counter
	fmt.Println("counter: ", counter)
}

func main() {
	var wg sync.WaitGroup
	numIncrements := 10

	// Launch multiple goroutines to increment the counter concurrently
	for i := 0; i < numIncrements; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			incrementCounter()
		}()

	}

	// Wait for all goroutines to finish
	wg.Wait()

	fmt.Printf("Final counter value: %d\n", counter)
}
