package main

import (
	"fmt"
	"time"
)

type user struct {
	firstName string
	lastName  string
	birthdate string
	createdAt time.Time
}

// it becomes a method of the struct
func (u user) outputUserDetails() {
	fmt.Println(u.firstName, u.lastName, u.birthdate)
}

func (u *user) clearUserName() {
	u.firstName = ""
	u.lastName = ""
}

func newUser(firstName, lastName, birthDate string) *user {
	return &user{
		firstName: firstName,
		lastName:  lastName,
		birthdate: birthDate,
		createdAt: time.Now(),
	}
}

func main() {
	userFirstName := getUserData("Please enter your first name: ")
	userLastName := getUserData("Please enter your last name: ")
	userBirthdate := getUserData("Please enter your birthdate (MM/DD/YYYY): ")

	//Normal declaration of struct
	/*var appUser user

	appUser = user{
		firstName: userFirstName,
		lastName:  userLastName,
		birthdate: userBirthdate,
		createdAt: time.Now(),
	} */
	//fmt.Println(appUser.birthdate)

	var appUser *user

	appUser = newUser(userFirstName, userLastName, userBirthdate)

	//outputUserDetails(&appUser) //Pointers --> passing address of the structure variable appUser
	appUser.outputUserDetails() //struct method
	appUser.clearUserName()
	appUser.outputUserDetails()

}

//Pointers
/*func outputUserDetails(u *user) { //getting address of the structure created by dereferencing method ie., using '*'
	fmt.Println(u.firstName, u.lastName, u.birthdate)
	fmt.Println((*u).firstName, (*u).lastName, (*u).birthdate)
}*/

func getUserData(promptText string) string {
	fmt.Print(promptText)
	var value string
	fmt.Scan(&value)
	return value
}
