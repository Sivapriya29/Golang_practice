package main

import (
	"errors"
	"fmt"
	"os"
	"strconv"
)

const accountBalanceFile = "balance.txt"

func getBalanceFromFile() (float64, error) {
	data, err := os.ReadFile(accountBalanceFile) //data inside this file will be in byte format
	if err != nil {
		return 1000, errors.New("Failed to read banace file.")
	}
	balanceToText := string(data)                         //we can't directly convert byte to float. so convert that to string
	balance, err := strconv.ParseFloat(balanceToText, 64) //convert that string to float using 'strconv' package
	if err != nil {
		return 1000, errors.New("Failed to parse stored balance value.")
	}
	return balance, nil
}

func writeBalanceToFile(balance float64) {
	balanceToText := fmt.Sprint(balance)
	os.WriteFile(accountBalanceFile, []byte(balanceToText), 0644) //string can be easily converted to byte so converting balance float to string. 0644 --> file permissions
}

func main() {
	var accountBalance, err = getBalanceFromFile()

	if err != nil {
		fmt.Println("ERROR")
		fmt.Println(err)
		fmt.Println("-------------------")
		return //to get out of the application once this error is received
		//panic("Can't continue, sorry") //this also stop the executed with this if block alone executed
	}

	for {
		fmt.Println("Welcome to Go bank!")
		fmt.Println("What do you want to do?")
		fmt.Println("1. Check Balance")
		fmt.Println("2. Deposit money")
		fmt.Println("3. Withdraw money")
		fmt.Println("4. Exit")

		var choice int
		fmt.Print("Your choice: ")
		fmt.Scan(&choice)

		//wantsCheckBalance := choice == 1

		switch choice {
		case 1:
			fmt.Println("Your balance is", accountBalance)
		case 2:
			fmt.Print("Your deposit amount: ")
			var depositAmount float64
			fmt.Scan(&depositAmount)
			if depositAmount <= 0 {
				fmt.Println("Invalid amount. Amount must be greater than 0.")
				//return
				continue
			}
			accountBalance += depositAmount
			fmt.Println("Balance updated!, New amount", accountBalance)
			writeBalanceToFile(accountBalance)
		case 3:
			fmt.Print("Withdrawal amount: ")
			var withdrawalAmount float64
			fmt.Scan(&withdrawalAmount)
			if withdrawalAmount <= 0 {
				fmt.Println("Invalid amount. Amount must be greater than 0.")
				//return
				continue
			}
			if withdrawalAmount > accountBalance {
				fmt.Println("Invalid amount. You can't withdraw more than you have.")
				//return
				continue
			}
			accountBalance -= withdrawalAmount
			fmt.Println("Balance updated!, New amount", accountBalance)
			writeBalanceToFile(accountBalance)
		default:
			fmt.Println("Goodbye!")
			fmt.Println("Thanks for choosing our bank.")
			return
		}

		/*if choice == 1 {
			fmt.Println("Your balance is", accountBalance)
		} else if choice == 2 {
			fmt.Print("Your deposit amount: ")
			var depositAmount float64
			fmt.Scan(&depositAmount)
			if depositAmount <= 0 {
				fmt.Println("Invalid amount. Amount must be greater than 0.")
				//return
				continue
			}
			accountBalance += depositAmount
			fmt.Println("Balance updated!, New amount", accountBalance)
		} else if choice == 3 {
			fmt.Print("Withdrawal amount: ")
			var withdrawalAmount float64
			fmt.Scan(&withdrawalAmount)
			if withdrawalAmount <= 0 {
				fmt.Println("Invalid amount. Amount must be greater than 0.")
				//return
				continue
			}
			if withdrawalAmount > accountBalance {
				fmt.Println("Invalid amount. You can't withdraw more than you have.")
				//return
				continue
			}
			accountBalance -= withdrawalAmount
			fmt.Println("Balance updated!, New amount", accountBalance)
		} else {
			fmt.Println("Goodbye!")
			break
		}*/
	}
	// fmt.Println("Thanks for choosing our bank.")
}
