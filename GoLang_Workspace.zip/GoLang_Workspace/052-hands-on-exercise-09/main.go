package main

import "fmt"

var output = 344.5

const input = 1000

func main() {
	z := 39
	fmt.Printf("The type of %v is %T\n", z, z)
	fmt.Printf("The type of %v is %T\n", output, output)
	fmt.Printf("The type of %v is %T\n", input, input)
}
