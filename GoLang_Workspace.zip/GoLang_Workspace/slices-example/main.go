package main

import (
	"fmt"
)

/*func main() {
	prices := []float64{10.99, 8.99}
	fmt.Println(prices[0:1])
	prices[1] = 9.99

	prices = append(prices, 5.99, 12.99, 29.99, 52.57)
	prices = prices[1:]
	fmt.Println(prices)

	discountPrices := []float64{101.99, 81.99}
	prices = append(prices, discountPrices...)
	fmt.Println(prices)
} */

func main() {
	prices := [4]float64{10.99, 45.99, 50.25, 20.0}
	fmt.Print("Original array: ")
	fmt.Println(prices)

	featuredPrices := prices[1:3] //it takes 1,2 indexed values from prices array - it includes 1 and excludes last value 3
	fmt.Println(featuredPrices)

	featuredPrices = prices[1:]
	fmt.Println(featuredPrices)

	//creating another slice from the slice
	highlightedPrice := featuredPrices[:1]
	fmt.Println(highlightedPrice)

	//we can modify the slice array values and it will also get modified in the original array
	featuredPrices = prices[1:]
	featuredPrices[0] = 199.45
	fmt.Print("Original array is modified: ")
	fmt.Println(prices)

	//length and capacity of slice
	fmt.Println(len(highlightedPrice), cap(highlightedPrice))

	marks := [7]int{78, 86, 92, 100, 65, 100, 200}
	//slicedMarks := marks[1:4]     //---> [86 92 100]
	slicedMarks := marks[2:] //---> [92 100 65]
	fmt.Print("slice 1: ")
	fmt.Println(slicedMarks)
	//anotherSliceMark := slicedMarks[2:]  //---> [100]
	anotherSliceMark := slicedMarks[:2] // ---> [92 100]
	fmt.Print("slice 2:")
	fmt.Println(anotherSliceMark)
	// anotherSliceMark = anotherSliceMark[1:]  //reslicing the slice
	// fmt.Println(anotherSliceMark)

	fmt.Println(len(slicedMarks), cap(slicedMarks))
	fmt.Println(len(anotherSliceMark), cap(anotherSliceMark))
}
