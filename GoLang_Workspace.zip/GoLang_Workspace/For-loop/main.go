package main

import "fmt"

func main() {
	x := 40
	y := 5
	fmt.Printf(" x=%v \n y=%v\n", x, y)

	//For loop
	//Type - 1
	for i := 0; i < 5; i++ {
		fmt.Printf("%v \t first loop\n", i)
	}

	//Type - 2
	for y < 10 {
		fmt.Printf("%v \t second loop\n", y)
		y++
	}

	//Type - 3  --> break - takes you out of the loop
	for {
		fmt.Printf("%v \t third loop \n", y)
		if y > 20 {
			break
		}
		y++
	}

	//Type - 4 --> continue - takes to next iteration
	for i := 0; i < 20; i++ {
		if i%2 != 0 {
			continue
		}
		fmt.Println("counting even numbers: ", i)
	}

	// nested loops
	for i := 0; i < 5; i++ {
		fmt.Println("--")
		for j := 0; j < 5; j++ {
			fmt.Printf("outer loop %v \t inner loop %v\n", i, j)
		}
	}

	// for range loop
	// data structures - slice
	xi := []int{42, 43, 44, 45, 46, 47}
	for i, v := range xi {
		fmt.Println("ranging over a slice", i, v)
	}

	// for range loop
	// data structures - map
	m := map[string]int{
		"James":      42,
		"Moneypenny": 32,
	}
	for k, v := range m {
		fmt.Println("ranging over a map", k, v)
	}
}
