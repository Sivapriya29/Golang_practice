package main

import (
	"fmt"

	"github.com/Sivapriya29/golang_workspace/sample"
)

func main() {
	fmt.Println("Hello Sivapriya!!")
	sample.SayHello()
}
