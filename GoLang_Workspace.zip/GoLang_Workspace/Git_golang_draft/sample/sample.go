package sample

import "fmt"

func main() {
	SayHello()
}

func SayHello() {
	fmt.Println("Welcome to Go!!")
}
