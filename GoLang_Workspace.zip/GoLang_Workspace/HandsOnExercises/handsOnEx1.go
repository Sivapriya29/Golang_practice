package main

import (
	"fmt"
	"math"
	"math/rand"
)

//func main() {
	fmt.Println(rand.Intn(4))
	fmt.Println(rand.Intn(4))
	fmt.Printf("square root is %g\n", math.Sqrt(9))
	fmt.Printf("Math pi: %f\n", math.Pi)
//}
