package main

import "fmt"

//func main() {
	fmt.Println(add(21, 42))
	sayHello()
	fmt.Println(swap("Hello", "GoLang developers"))
	fmt.Println(split(10))

//}

// return type 1
func add(x, y int) int {
	return x + y
}

func sayHello() {
	fmt.Println("Hello GOlang developer !!")
}

//return type 2
func swap(x, y string) (string, string) {
	return y, x
}

//return type 3 --> naked return
func split(sum int) (x, y int) {
	x = sum * 4 / 9
	y = sum - x
	return
}
