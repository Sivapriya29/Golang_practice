package main

import (
	"fmt"
	"math"
)

var i, j int = 1, 2

const Pi = 3.14

//func main() {
	var c, java = true, "no!"
	var python bool
	k := 3.5
	fmt.Println(i)
	fmt.Println(j)
	fmt.Println(c)
	fmt.Println(java)
	fmt.Println(python)
	fmt.Println(k)
	fmt.Printf("%T\t %T\t %T\t %T\t %T\t %T\t\n", i, j, c, java, python, k)
	//Type conversion
	var x, y int = 3, 4
	var f float64 = math.Sqrt(float64(x*x + y*y))
	var z uint = uint(f)
	fmt.Println(x, y, z)
	//Type inference
	v := 0.867 + 0.5i
	fmt.Printf("%v is of type %T\n", v, v)
	fmt.Println("value of Pi is ", Pi)
//}
