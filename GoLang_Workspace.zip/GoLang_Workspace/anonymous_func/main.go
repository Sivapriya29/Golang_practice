package main

import "fmt"

func main() {

	foo()

	//Anonymous function - Type-1
	func() {
		fmt.Println("This is a anonymous function with no parameters and no return value")
	}()

	//Anonymous function - Type-2
	func(s string) {
		fmt.Println("Anonymous func with parameter and no return value ", s)
	}("Functions in GOLANG")

	//Anonymous function - Type-3
	stringFunc := func(s1 string) string {
		fmt.Println("Anonymous function with parameters and return value")
		return fmt.Sprint(s1)
	}("Happy Learning!!")

	fmt.Println(stringFunc)

	//Function expression

	x := func() {
		fmt.Println("Function as expression - Type-1")
	}

	y := func(s string) {
		fmt.Println("Function as expression - Type-2 ", s)
	}

	x()
	y("FuncExpression Example")

}

func foo() {
	fmt.Println("Welcome!!")
}
