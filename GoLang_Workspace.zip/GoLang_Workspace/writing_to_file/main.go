package main

import (
	"log"
	"os"
)

func main() {
	file, err := os.Create("Output.txt")

	if err != nil {
		log.Fatalf("error %s", err)
	}
	defer file.Close()

	stringWord := []byte("Hello Sivapriya!")
	_, err = file.Write(stringWord)

	if err != nil {
		log.Fatalf("error %s", err)
	}
}
