package main

import "fmt"

func main() {
	websites := map[string]string{
		"Google":              "https://google.com",
		"Amazon Web Services": "https://aws.com",
	}
	fmt.Println(websites)

	//accessing particular value in map
	fmt.Println(websites["Amazon Web Services"])

	//adding key-value pairs to map
	websites["LinkedIn"] = "https://linkedin.com"
	fmt.Println(websites)

	//deleting any key-value pair in maps
	delete(websites, "Google")
	fmt.Println(websites)
}
