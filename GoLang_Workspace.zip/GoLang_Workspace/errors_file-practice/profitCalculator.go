package main

import (
	"errors"
	"fmt"
	"os"
)

func main() {
	revenue, err1 := getUserInput("Revenue: ")
	// if err != nil {
	// 	fmt.Println(err)
	// 	return
	//panic(err) //it stops program and outputs the error trace
	// }

	expenses, err2 := getUserInput("Expenses: ")
	// if err != nil {
	// 	fmt.Println(err)
	// 	return
	// }

	taxRate, err3 := getUserInput("Tax rate: ")
	if err1 != nil || err2 != nil || err3 != nil {
		fmt.Println(err1)
		return
	}

	ebt, profit, ratio := calculateFinancials(revenue, expenses, taxRate)

	fmt.Printf("Expenses before tax: %.2f\n", ebt)
	fmt.Printf("Profit: %.2f\n", profit)
	fmt.Printf("Ratio: %.2f\n", ratio)
	storeResult(ebt, profit, ratio)

}

func storeResult(ebt, profit, ratio float64) {
	results := fmt.Sprintf("EBT: %.1f\nProfit: %.1f\nRatio:%.3f\n", ebt, profit, ratio)
	os.WriteFile("results.txt", []byte(results), 0644)
}

func getUserInput(Infotext string) (float64, error) {
	var userInput float64
	fmt.Print(Infotext)
	fmt.Scan(&userInput)
	if userInput <= 0 {
		//fmt.Println("Invalid userinput. UserInput should not be less or equal to 0.")
		return 0, errors.New("Invalid userinput. UserInput should not be less or equal to 0.")
	}
	return userInput, nil
}

func calculateFinancials(revenue, expenses, taxRate float64) (float64, float64, float64) {
	ebt := revenue - expenses
	profit := ebt * (1 - taxRate/100)
	ratio := ebt / profit
	return ebt, profit, ratio
}
