package main

import (
	"fmt"
	"math/rand"
)

func main() {
	m := map[string]int{
		"James":      32,
		"MoneyPenny": 45,
	}

	for key, value := range m {
		fmt.Printf("Key is %v\tValue is %v\n", key, value)
	}

	if val, ok := m["Q"]; ok {
		fmt.Println("Key is found", val)
	} else {
		fmt.Println("Key not found :-(")
	}

	c := 1
	//for i := 0; i < 100; i++ {
	if x := rand.Intn(5); x == 3 {
		fmt.Printf("total count %v \t x is %v\n", c, x)
		c++
	}
	//}

	fmt.Printf("true && true \t\t%v\n", (true && true))
	fmt.Printf("true && false \t\t%v\n", (true && false))
	fmt.Printf("true || true \t\t%v\n", (true || true))
	fmt.Printf("true || false \t\t%v\n", (true || false))
	fmt.Printf("!true \t\t\t%v\n", !true)

}
