package main

import "fmt"

func main() {
	age := 32

	var agePointer *int
	agePointer = &age

	fmt.Println("age: ", age)
	fmt.Println("age: ", &age)
	fmt.Println("age: ", *agePointer)
	ageCalc(&age)

}
func ageCalc(age *int) int {
	fmt.Println(age)
	fmt.Println(*age)
	return *age
}
