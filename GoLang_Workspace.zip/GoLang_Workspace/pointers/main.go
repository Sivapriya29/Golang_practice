package main

import "fmt"

func main() {
	age := 32
	var agePointer *int
	agePointer = &age

	fmt.Println("Address of age is: ", agePointer) //to get address of the value we use '&' symbol
	fmt.Println("Address of age is: ", &age)       //to get address of the value we use '&' symbol
	fmt.Println("Value of age is: ", *agePointer)  //to get value of the pointer variable we use 'deferencing' '*' symbol

	/*Type-1*/
	adultYears := editAgeToAdultYears(&age)
	adultYears = editAgeToAdultYears(agePointer)
	fmt.Println(adultYears)

	/* Type-2 */
	// editAgeToAdultYears(agePointer)
	// fmt.Println(age)
}

/* Type-1 --> avoid unnecessary value copies */
func editAgeToAdultYears(age *int) int {
	return *age - 18
}

/*Type -2 --> Data mutation (overriding the value) */
/*func editAgeToAdultYears(age *int) {
	*age = *age - 18
}*/
