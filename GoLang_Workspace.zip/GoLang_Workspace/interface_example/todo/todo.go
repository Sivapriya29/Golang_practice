package todo

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
)

type Todo struct {
	Text string `json:"text"`
}

// Struct method
func (todo Todo) Save() error {
	fileName := "todo.json"
	json, err := json.Marshal(todo) //this returns error so in func declaration we need to ad error return type
	if err != nil {
		return err
	}
	return os.WriteFile(fileName, json, 0644) //this also returns error, so we are returning this whole statement in return
}

// Constructor
func New(content string) (Todo, error) {

	if content == "" {
		return Todo{}, errors.New("Invalid input.")
	}
	return Todo{
		Text: content,
	}, nil
}

// Struct method
func (todo Todo) Display() {
	fmt.Println(todo.Text)
}
