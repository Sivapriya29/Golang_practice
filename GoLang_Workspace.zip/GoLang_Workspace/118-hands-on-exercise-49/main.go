package main

import "fmt"

func main() {
	m := make(map[string][]string)

	m[`bond_james`] = []string{`shaken, not stirred`, `martinis`, `fast cars`}
	m[`moneypenny_jenny`] = []string{`intelligence`, `literature`, `computer science`}
	m[`no_dr`] = []string{`cats`, `ice cream`, `sunsets`}
	m[`fleming_ian`] = []string{`steaks`, `cigars`, `espionage`}
	// delete(m, `no_dr`)

	for k, v := range m {
		fmt.Printf("%v\t%v\n", k, v)
		for index, val := range v {
			fmt.Printf("key:%v\t i:%v value:%v\n", k, index, val)
		}
		fmt.Println("----------------")
	}

	fmt.Println("------------record deleted----------------")
	delete(m, `no_dr`)
	fmt.Println("------------record deleted----------------")

	for k, v := range m {
		fmt.Printf("%v\t%v\n", k, v)
		for index, val := range v {
			fmt.Printf("key:%v\t i:%v value:%v\n", k, index, val)
		}
	}
}
