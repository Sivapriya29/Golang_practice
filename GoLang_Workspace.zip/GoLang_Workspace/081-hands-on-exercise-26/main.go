package main

import "fmt"

func main() {
	i := 15

	for {
		if i < 0 {
			break
		}
		fmt.Println(i)
		i--
	}
}
