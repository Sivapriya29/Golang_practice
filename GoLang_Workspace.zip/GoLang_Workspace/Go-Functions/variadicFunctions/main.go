package main

import "fmt"

func main() {
	numbers := []int{1, 2, 3, 4}

	sum := sumUp(1, numbers...) //passing slice as parameter
	sum1 := sumUp(1, 2, 5, 6)

	fmt.Println(sum)
	fmt.Println(sum1)
}

//func sumUp(numbers ...int) int {
func sumUp(startingValue int, numbers ...int) int {
	sum := 0

	for _, val := range numbers {
		sum += val
	}
	fmt.Println(startingValue)
	fmt.Println(numbers)
	return sum
}
