package main

import "fmt"

type operateNumbers func(int, int) int

func main() {
	numbers := []int{21, 42, 69, 50}

	y := 10

	addedValue := operation(&numbers, y, add)
	subValue := operation(&numbers, y, subtract)
	multiplyValue := operation(&numbers, y, multiply)
	dividedValue := operation(&numbers, y, divide)
	moduloValue := operation(&numbers, y, modulo)

	fmt.Println("Add operation:", addedValue)
	fmt.Println("Subtract operation:", subValue)
	fmt.Println("Multiply operation:", multiplyValue)
	fmt.Println("Divide operation:", dividedValue)
	fmt.Println("Modulo operation:", moduloValue)
}

func add(x, y int) int {
	return x + y
}

func subtract(x, y int) int {
	return x - y
}

func multiply(x, y int) int {
	return x * y
}

func divide(x, y int) int {
	return x / y
}

func modulo(x, y int) int {
	return x % y
}

func operation(numbers *[]int, y int, operate operateNumbers) []int {
	opNumbers := []int{}

	for _, val := range *numbers {
		opNumbers = append(opNumbers, operate(val, y))
		//fmt.Println(opNumbers)
	}
	return opNumbers
}
