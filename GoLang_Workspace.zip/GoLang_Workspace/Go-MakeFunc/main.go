package main

import "fmt"

//working with type Aliases
type floatMap map[string]float64

func (m floatMap) output() {
	fmt.Println(m)
}

func main() {
	/* make function for slices */
	userNames := make([]string, 2, 5)
	//to add names for which make() already allocates space in memory in array (2 in make func)
	userNames[0] = "Julie"
	//userNames[1] = "Jack"
	//to append values that are not allocated in memory using make func
	userNames = append(userNames, "Max")
	userNames = append(userNames, "Manuel")
	userNames = append(userNames, "Rob")
	userNames = append(userNames, "Kelvin")
	userNames = append(userNames, "Fahrenheit")
	userNames = append(userNames, "Jeni")

	fmt.Println(userNames)

	/* make function for maps */
	//courseRatings := make(map[string]float64, 3)
	courseRatings := make(floatMap, 3)

	courseRatings["Go"] = 4.7
	courseRatings["React"] = 4.8
	courseRatings["angular"] = 4.5

	//fmt.Println(courseRatings)
	courseRatings.output()

	//for loop for slices
	for index, value := range userNames {
		fmt.Println("Index:", index)
		fmt.Println("Values:", value)
	}

	//for loop for Maps
	for Key, value := range courseRatings {
		fmt.Println("Key:", Key)
		fmt.Println("Value:", value)
	}
}
