package main

import "fmt"

func main() {
	result := add(5, 20)
	fmt.Println(result)
	result1 := add(5.5, 20.25)
	fmt.Println(result1)
	result2 := add("Hello", "developer")
	fmt.Println(result2)
}

func add[T int | float64 | string](a, b T) T {
	return a + b
}
