package main

import "fmt"

type engine struct {
	electric bool
}
type vehicle struct {
	engine
	make  string
	model string
	doors int
	color string
}

func main() {
	v1 := vehicle{
		engine: engine{
			electric: true,
		},
		make:  "Ford",
		model: "Mustang",
		doors: 4,
		color: "Blue",
	}

	v2 := vehicle{
		engine: engine{
			electric: false,
		},
		make:  "Toyota",
		model: "Tundra",
		doors: 2,
		color: "White",
	}
	fmt.Println(v1)
	fmt.Println(v2)

	fmt.Println(v1.electric, v1.engine.electric, v1.engine)
	fmt.Println(v2.electric, v2.engine.electric, v2.engine)

	fmt.Println(v1.make, v1.model, v1.doors, v1.color)
	fmt.Println(v2.make, v2.model, v2.doors, v2.color)

	//anonymous struct
	p1 := struct {
		first     string
		friends   map[string]int
		favDrinks []string
	}{
		first: "James",
		friends: map[string]int{
			"Jenny": 27,
			"Q":     87,
			"Ian":   47,
		},
		favDrinks: []string{
			"Martini",
			"Water",
		},
	}

	for key1, val1 := range p1.friends {
		fmt.Printf("key:%v\tage:%v\n", key1, val1)
	}

	for _, v := range p1.favDrinks {
		fmt.Println(v)
	}
}
