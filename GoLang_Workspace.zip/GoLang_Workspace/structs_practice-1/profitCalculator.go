package main

import (
	"fmt"

	"example.com/profitStructs/input"
)

func main() {
	revenue, expenses, taxRate := getProfitData()

	var inputTaxCredit input.InputTax

	inputTaxCredit, err := input.New(revenue, expenses, taxRate)
	if err != nil {
		fmt.Println(err)
		return
	}

	err = inputTaxCredit.SaveInputTax()
	if err != nil {
		fmt.Println("Saving to file failed.")
		return
	}

	fmt.Println("Saved to file succeeded!")

	ebt, profit, ratio := calculateFinancials(revenue, expenses, taxRate)
	fmt.Printf("Expenses before tax: %.2f\n", ebt)
	fmt.Printf("Profit: %.2f\n", profit)
	fmt.Printf("Ratio: %.2f\n", ratio)

}

func getProfitData() (float64, float64, float64) {
	revenue := getUserInput("Revenue: ")
	expenses := getUserInput("Expenses: ")
	taxRate := getUserInput("Tax Rate: ")
	return revenue, expenses, taxRate
}

func getUserInput(infoText string) float64 {
	fmt.Print(infoText)
	var value float64
	fmt.Scan(&value)
	return value
}

func calculateFinancials(revenue, expenses, taxRate float64) (float64, float64, float64) {
	ebt := revenue - expenses
	profit := ebt * (1 - taxRate/100)
	ratio := ebt / profit
	return ebt, profit, ratio
}
