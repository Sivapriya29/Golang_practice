package input

import (
	"encoding/json"
	"errors"
	"os"
	"time"
)

type InputTax struct {
	Revenue   float64   `json:"revenue"`
	Expenses  float64   `json:"expenses"`
	TaxRate   float64   `json:"taxRate"`
	CreatedAt time.Time `json:"created_at"`
}

func (inputTax InputTax) SaveInputTax() error {
	fileName := "input_tax_credit.json"
	json, err := json.Marshal(inputTax)
	if err != nil {
		return err
	}
	return os.WriteFile(fileName, json, 0644)
}

func New(revenue, expenses, taxRate float64) (InputTax, error) {
	if revenue <= 0 || expenses <= 0 || taxRate <= 0 {
		return InputTax{}, errors.New("Invalid user input.")
	}
	return InputTax{
		Revenue:   revenue,
		Expenses:  expenses,
		TaxRate:   taxRate,
		CreatedAt: time.Now(),
	}, nil
}
