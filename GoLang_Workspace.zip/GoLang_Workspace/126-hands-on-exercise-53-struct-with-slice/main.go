package main

import "fmt"

type person struct {
	firstName  string
	lastName   string
	iceFlavors []string
}

func main() {
	p1 := person{
		firstName:  "Siva",
		lastName:   "priya",
		iceFlavors: []string{"Double chocalate", "blackcurrent", "vanilla", "starwberry", "Red velvet"},
	}

	p2 := person{
		firstName:  "Jenny",
		lastName:   "Moneypenny",
		iceFlavors: []string{"Strawberry", "Chocolate"},
	}

	// fmt.Printf("%T \t %#v \t %v\n", p1, p1, p1)
	// fmt.Printf("%T \t %#v \t %v\n", p2, p2, p2)

	// fmt.Println(p1.iceFlavors)
	// fmt.Println(p2.iceFlavors)

	// for key, val := range p1.iceFlavors {
	// 	fmt.Println(key, val)
	// }
	// for key, val := range p2.iceFlavors {
	// 	fmt.Println(key, val)
	// }

	m := map[string]person{
		p1.lastName: p1,
		p2.lastName: p2,
	}
	fmt.Println(m)

	for _, v := range m {
		fmt.Println(v)
		for _, val := range v.iceFlavors {
			fmt.Println(val)
		}
	}
}
