package main

import "fmt"

func main() {
	//declaring array elements
	var productNames [4]string = [4]string{"A book"} //type-1
	prices := [4]float64{10.99, 45.99, 50.25, 20.0}  //type-2
	marks := [...]int{80, 95, 75, 56}                //type-3 // Initializes an array with size inferred from elements

	fmt.Println(marks[0]) //Prints the first element of the array
	fmt.Println(len(marks))

	fmt.Println(productNames)

	productNames[2] = "A carpet show" // Modifies the second element of the array
	fmt.Println(productNames)

	// Iterating over the array
	fmt.Println("Array elements:")
	for i := 0; i < len(prices); i++ {
		fmt.Println(prices[i])
	}
}
