package main

import "fmt"

func main() {
	prices := [5]int{10, 20, 13, 48}
	fmt.Println(prices)

	// for i := 0; i < len(prices); i++ {
	// 	fmt.Println(i)
	// 	fmt.Println(prices[i])
	// }
	slice := prices[1:3]
	fmt.Println(slice)
}
