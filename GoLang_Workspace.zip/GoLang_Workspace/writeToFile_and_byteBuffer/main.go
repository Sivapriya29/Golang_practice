package main

import (
	"bytes"
	"fmt"
	"io"
	"log"
	"os"
)

type person struct {
	first string
}

func (p person) writeOut(w io.Writer) {
	w.Write([]byte(p.first))
}

func main() {
	p1 := person{
		first: "Jenny",
	}

	file, err := os.Create("output.txt")

	if err != nil {
		log.Fatalf("Errors %s", err)
	}

	defer file.Close()

	var b bytes.Buffer

	p1.writeOut(file)
	p1.writeOut(&b)
	fmt.Println(b.String())
	fmt.Println(b)
	fmt.Println(&b)

}
