// package main

// import "fmt"

// func main() {
// 	/* variables diff datatypes and diff declarations */
// 	var a int = 534 //var when specificity is required
// 	b := 64.5       //short declaration
// 	c := "Hello"
// 	d := true
// 	var e float32             //var when specificity is required
// 	g, str := 45, "Happiness" //multiple initializations
// 	g, h, _ := 56, 67, 98     //blank identifier

// 	fmt.Printf("Type of %v is %T\n", a, a)
// 	fmt.Printf("Type of %v is %T\n", b, b)
// 	fmt.Printf("Type of %v is %T\n", c, c)
// 	fmt.Printf("Type of %v is %T\n", d, d)
// 	fmt.Printf("Type of %v is %T\n", e, e) //print value for zero value(not assigned any value)
// 	fmt.Println(g, str)
// 	fmt.Println(g, h)

// 	/* Type conversion */
// 	e = float32(b)
// 	fmt.Printf("Type if %v is %T\n", e, e)

// 	/* Binary and Hexadecimals */
// 	fmt.Printf("Binary for %d is %b\n", a, a)
// 	fmt.Printf("Hexadecimal for %d is %x\n", a, a)

// 	/*Using Sprintf */
// 	formattedValue := fmt.Sprintf("formatted value is: %.2f", float64(a)/b)
// 	fmt.Printf(formattedValue)

// 	/*print multi line string using backticks */
// 	fmt.Println(`
// 	A Necessary Autumn Inside Each
// 	~Rumi~

// 	You and I have spoken all these words,
// 	but as for the way we have to go,
// 	words are no preparation.
// 	There is no getting ready, other than grace....
// 	Inside each of us, there’s continual autumn.
// 	Our leaves fall and are blown out over the water.
// 	A crow sits in the blackened limbs
// 	and talks about what’s gone....
// 	There’s a necessary dying,
// 	and then Jesus is breathing again.
// 	Very little grows on jagged rock.
// 	Be ground. Be crumbled, so wildflowers
// 	will come up where you are.
// 	You’ve been stony for too many years.
// 	Try something different.
// 	Surrender.
// 	`)
// 	var x uint8 = 255
// 	var y int8 = 127

// 	fmt.Printf("%v is of type %T\n", x, x)
// 	fmt.Printf("%v is of type %T\n", y, y)
// }
