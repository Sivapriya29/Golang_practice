package models

type Company struct {
	ID    string `gorm:"primaryKey;type:uuid"`
	Name  string
	Users []User `gorm:"foreignKey:CompanyId"`
}
