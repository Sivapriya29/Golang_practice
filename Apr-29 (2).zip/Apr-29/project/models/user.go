package models

type User struct {
	ID        string `gorm:"primaryKey;type:uuid"`
	Name      string
	Email     string
	Mobile    string
	CompanyID string  `gorm:"type:uuid" json:"company_id"`
	Company   Company `gorm:"foreignKey:CompanyId"`
}
