-- +goose Up
-- +goose StatementBegin
CREATE TABLE IF NOT EXISTS companies(
    id UUID PRIMARY KEY,
    "name" TEXT
);

CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY,
    "name" TEXT,
    "email" TEXT,
    mobile TEXT,
    company_id UUID REFERENCES companies(id)
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
-- +goose StatementEnd
