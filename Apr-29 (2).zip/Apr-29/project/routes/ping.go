package routes

import (
	"project/handlers"

	"github.com/gin-gonic/gin"
)

func pingRoutes(router *gin.Engine) {
	router.GET("/ping", handlers.Ping)
}
