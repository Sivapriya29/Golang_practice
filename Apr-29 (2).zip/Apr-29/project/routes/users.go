package routes

import (
	"project/handlers"

	"github.com/gin-gonic/gin"
)

func userRoutes(router *gin.Engine) {
	router.POST("/users", handlers.CreateUser)
	router.GET("/users", handlers.GetAllUsersHandler)
	router.GET("/user/:id", handlers.GetUserByIDHandler)
	router.PUT("/user/:id", handlers.UpdateUserByIDHandler)
	router.DELETE("/user/:id", handlers.DeleteUserByIDHandler)
}
