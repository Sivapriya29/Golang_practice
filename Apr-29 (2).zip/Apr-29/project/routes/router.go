package routes

import (
	"project/middlewares"

	"github.com/gin-gonic/gin"
)

func GetRouter() *gin.Engine {
	router := gin.Default()

	router.Use(middlewares.CORSMiddleware())

	pingRoutes(router)
	userRoutes(router)

	return router
}
