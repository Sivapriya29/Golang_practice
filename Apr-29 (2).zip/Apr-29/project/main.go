package main

import "project/routes"

func main() {
	r := routes.GetRouter()
	r.Run(":3000")
}
