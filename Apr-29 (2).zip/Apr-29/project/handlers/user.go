package handlers

import (
	"net/http"
	"project/database/models"
	"project/services/users"

	//"project/daos/users"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

func CreateUser(c *gin.Context) {
	user := &models.User{}
	// Generate a new UUID for the user
	uuidValue := uuid.New()

	// Convert the UUID to string format and assign it to the ID field
	user.ID = uuidValue.String()

	if err := c.Bind(user); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": err.Error(),
		})
		return
	}

	err := users.CreateUser(c, user)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": err.Error(),
		})
		return
	}

	c.JSON(http.StatusCreated, gin.H{
		"msg": "created",
	})
}

// GetAllUsersHandler retrieves all users and returns them.
func GetAllUsersHandler(c *gin.Context) {
	users, err := users.GetAllUsers(c)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": err.Error(),
		})
		return
	}

	c.JSON(http.StatusOK, users)
}

// GetUserByIDHandler retrieves a user by their ID.
func GetUserByIDHandler(c *gin.Context) {
	userID := c.Param("id")
	user, err := users.GetUserByID(c, userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": err.Error(),
		})
		return
	}
	if user == nil {
		c.JSON(http.StatusNotFound, gin.H{
			"error": "User not found",
		})
		return
	}
	c.JSON(http.StatusOK, user)
}

// UpdateUserByIDHandler updates a user by their ID.
func UpdateUserByIDHandler(c *gin.Context) {
	userID := c.Param("id")
	var updatedUser models.User
	if err := c.BindJSON(&updatedUser); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": err.Error(),
		})
		return
	}
	err := users.UpdateUserByID(c, userID, &updatedUser)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": err.Error(),
		})
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"msg": "User updated successfully",
	})
}

// DeleteUserByIDHandler deletes a user by their ID.
func DeleteUserByIDHandler(c *gin.Context) {
	userID := c.Param("id")
	err := users.DeleteUserByID(c, userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": err.Error(),
		})
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"msg": "User deleted successfully",
	})
}
