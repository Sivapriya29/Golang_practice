package users

import (
	"database/sql"
	"fmt"
	"os"
	"project/database/models"

	"github.com/gin-gonic/gin"
	//"github.com/google/uuid"
	_ "github.com/lib/pq"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

var db *gorm.DB

func init() {
	sqlDB, err := sql.Open("postgres", "postgres://postgres:root@Localhost:5432/test?sslmode=disable")
	if err != nil {
		fmt.Println("Unable to open postgres connection.Err:", err)
		os.Exit(1)
	}

	sqlDB.SetConnMaxIdleTime(5)
	sqlDB.SetMaxIdleConns(5)
	sqlDB.SetConnMaxLifetime(10)

	db, err = gorm.Open(postgres.New(postgres.Config{
		Conn: sqlDB,
	}), &gorm.Config{})
	if err != nil {
		fmt.Println("Unable to create gorm Connection.Err:", err)
		os.Exit(1)
	}

}

type User struct {
}

func NewUser() *User {
	return &User{}
}

func (u *User) Create(ctx *gin.Context, user *models.User) error {
	err := db.Save(user).Error

	if err != nil {
		return err
	}
	return nil
}

// GetAllUsers retrieves all users from the database.
func (u *User) GetAllUsers(ctx *gin.Context) ([]models.User, error) {
	var users []models.User
	err := db.Find(&users).Error
	if err != nil && err != gorm.ErrRecordNotFound {
		return nil, err
	}
	return users, nil
}

// GetUserByID retrieves a user by their ID from the database.
func (u *User) GetUserByID(ctx *gin.Context, userID string) (*models.User, error) {
	var user models.User
	//err := db.Where("id = ?", userID).First(&user).Error
	err := db.Debug().Preload("Company").Find(&user, "id = ?", userID).Error
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			return nil, nil // Return nil if user not found
		}
		return nil, err
	}
	return &user, nil
}

// UpdateUserByID updates a user by their ID in the database.
func (u *User) UpdateUserByID(ctx *gin.Context, userID string, updatedUser *models.User) error {
	err := db.Model(&models.User{}).Where("id = ?", userID).Updates(updatedUser).Error
	if err != nil {
		return err
	}
	return nil
}

// DeleteUserByID deletes a user by their ID from the database.
func (u *User) DeleteUserByID(ctx *gin.Context, userID string) error {
	err := db.Where("id = ?", userID).Delete(&models.User{}).Error
	if err != nil {
		return err
	}
	return nil
}
