package users

import (
	"project/daos/users"
	"project/database/models"

	"github.com/gin-gonic/gin"
)

func CreateUser(ctx *gin.Context, user *models.User) error {
	return users.NewUser().Create(ctx, user)
}

// GetAllUsers retrieves all users and returns them.
func GetAllUsers(ctx *gin.Context) ([]models.User, error) {
	userDAO := users.NewUser()
	return userDAO.GetAllUsers(ctx)
}

// GetUserByID retrieves a user by their ID.
func GetUserByID(ctx *gin.Context, userID string) (*models.User, error) {
	userDAO := users.NewUser()
	return userDAO.GetUserByID(ctx, userID)
}

// UpdateUserByID updates a user by their ID.
func UpdateUserByID(ctx *gin.Context, userID string, updatedUser *models.User) error {
	userDAO := users.NewUser()
	return userDAO.UpdateUserByID(ctx, userID, updatedUser)
}

// DeleteUserByID deletes a user by their ID.
func DeleteUserByID(ctx *gin.Context, userID string) error {
	userDAO := users.NewUser()
	return userDAO.DeleteUserByID(ctx, userID)
}
